#!/bin/bash
set -euo pipefail
echo "URPi installer - dockerized workflow"

if ! command -v docker >/dev/null 2>&1; then
  echo "Docker chybí. Nainstaluj Docker." >&2
  exit 1
fi
if ! docker compose version >/dev/null 2>&1; then
  echo "Docker Compose plugin není dostupný." >&2
  exit 1
fi

docker compose up -d --build
echo "Dashboard: http://<host>:8000"
echo "Pozor: ADB kontejner používá privileged a host USB passthrough."
