from flask import Flask, request, jsonify, render_template
import os, subprocess, uuid

APP_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.join(APP_DIR, 'uploads')
os.makedirs(UPLOAD_DIR, exist_ok=True)

app = Flask(__name__, static_folder='static', template_folder='templates')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/devices')
def devices():
    try:
        out = subprocess.check_output(['adb', 'devices', '-l'], stderr=subprocess.STDOUT).decode()
    except Exception as e:
        out = str(e)
    return jsonify({'raw': out})

@app.route('/api/upload_apk', methods=['POST'])
def upload_apk():
    f = request.files.get('apk')
    if not f:
        return jsonify({'error':'no file'}), 400
    fname = str(uuid.uuid4()) + '_' + f.filename
    path = os.path.join(UPLOAD_DIR, fname)
    f.save(path)
    return jsonify({'saved': fname})

@app.route('/api/install_apk', methods=['POST'])
def install_apk():
    data = request.json or {}
    fname = data.get('filename')
    device = data.get('device')
    if not fname:
        return jsonify({'error':'missing filename'}), 400
    path = os.path.join(UPLOAD_DIR, fname)
    if not os.path.exists(path):
        return jsonify({'error':'file not found'}), 404
    cmd = ['adb']
    if device:
        cmd += ['-s', device]
    cmd += ['install', '-r', path]
    try:
        out = subprocess.check_output(cmd, stderr=subprocess.STDOUT, timeout=120).decode()
        return jsonify({'out': out})
    except subprocess.CalledProcessError as e:
        return jsonify({'error': e.output.decode()}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/logcat')
def logcat():
    device = request.args.get('device')
    cmd = ['adb']
    if device:
        cmd += ['-s', device]
    cmd += ['logcat', '-d', '-v', 'time', '*:I']
    try:
        out = subprocess.check_output(cmd, stderr=subprocess.STDOUT, timeout=10).decode()
    except Exception as e:
        out = str(e)
    return jsonify({'log': out[-2000:]})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000)
