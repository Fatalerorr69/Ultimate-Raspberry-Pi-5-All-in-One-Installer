#!/bin/bash
set -euo pipefail
echo "1) Kontrola kernel modulů binder a ashmem..."
if ! grep -qE "binder|ashmem" /proc/modules 2>/dev/null; then
  modprobe ashmem_linux || true
  modprobe binder_linux || true
fi

if [ ! -c /dev/binder ] && [ ! -c /dev/binderfs ]; then
  echo "/dev/binder chybí. Waydroid vyžaduje binder/ashmem."
fi

echo "Doporučeno: apt update && apt install -y curl wget ca-certificates python3 lxc"
