#!/bin/bash

set -euo pipefail
### **🔧 install.sh** (Hlavní instalační skript)
```bash
#!/bin/bash
set -e

# =============================================
# KONFIGURAČNÍ PROMĚNNÉ
# =============================================

# Systémové nastavení
PI_USER=$(whoami)
PI_HOSTNAME=$(hostname)
TIMEZONE="Europe/Prague"
DOCKER_NETWORK="pi5-network"

# Barvy pro výstup
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Proměnné pro konfiguraci
GITHUB_USERNAME=""
GITHUB_EMAIL=""
SELECTED_SERVICES=()
PIHOLE_PASSWORD=""
VAULTWARDEN_PASSWORD=""

# =============================================
# FUNKCE PRO LOGOVÁNÍ
# =============================================

log() { echo -e "${GREEN}[$(date +'%H:%M:%S')]${NC} $1"; }
log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }
log_step() { echo -e "${CYAN}=== $1 ===${NC}"; echo; }

# =============================================
# BEZPEČNOSTNÍ KONTROLY
# =============================================

check_security() {
    log_step "BEZPEČNOSTNÍ KONTROLA"
    
    if [[ $EUID -eq 0 ]]; then
        log_error "Skript nesmí být spuštěn jako root!"
    fi
    
    log_success "Bezpečnostní kontrola prošla"
}

check_dependencies() {
    log_step "KONTROLA ZÁVISLOSTÍ"
    
    local deps=("curl" "wget" "git")
    local missing=()
    
    for dep in "${deps[@]}"; do
        if ! command -v "$dep" &> /dev/null; then
            missing+=("$dep")
        fi
    done
    
    if [[ ${#missing[@]} -gt 0 ]]; then
        log_info "Instalace chybějících závislostí: ${missing[*]}"
        sudo apt update && sudo apt install -y "${missing[@]}"
    fi
    
    log_success "Všechny závislosti jsou nainstalovány"
}

check_raspberry_pi() {
    log_step "KONTROLA ZAŘÍZENÍ"
    
    if ! grep -q "Raspberry Pi" /proc/device-tree/model 2>/dev/null; then
        log_warning "Tento skript je optimalizovaný pro Raspberry Pi"
        read -p "Chcete pokračovat i tak? (y/n): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi
}

# =============================================
# INTERAKTIVNÍ KONFIGURACE
# =============================================

show_banner() {
    clear
    cat << "EOF"
    
    ██████╗  █████╗ ███████╗██████╗ ██████╗ ███████╗██████╗ ██████╗ ██╗   ██╗
    ██╔══██╗██╔══██╗██╔════╝██╔══██╗██╔══██╗██╔════╝██╔══██╗██╔══██╗╚██╗ ██╔╝
    ██████╔╝███████║███████╗██████╔╝██████╔╝█████╗  ██████╔╝██████╔╝ ╚████╔╝ 
    ██╔══██╗██╔══██║╚════██║██╔══██╗██╔══██╗██╔══╝  ██╔══██╗██╔══██╗  ╚██╔╝  
    ██║  ██║██║  ██║███████║██║  ██║██║  ██║███████╗██║  ██║██║  ██║   ██║   
    ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   
                                                                              
    ██████╗ ██╗   ██╗    ██████╗ ██╗5    ██████╗ ███████╗██████╗ ███████╗██╗
    ██╔══██╗╚██╗ ██╔╝    ██╔══██╗██║    ██╔═══██╗██╔════╝██╔══██╗██╔════╝██║
    ██████╔╝ ╚████╔╝     ██████╔╝██║    ██║   ██║█████╗  ██████╔╝███████╗██║
    ██╔══██╗  ╚██╔╝      ██╔═══╝ ██║    ██║   ██║██╔══╝  ██╔══██╗╚════██║╚═╝
    ██║  ██║   ██║       ██║     ██║    ╚██████╔╝███████╗██║  ██║███████║██╗
    ╚═╝  ╚═╝   ╚═╝       ╚═╝     ╚═╝     ╚═════╝ ╚══════╝╚═╝  ╚═╝╚══════╝╚═╝

                Ultimate Raspberry Pi 5 All-in-One Installer v3.0
                       Kompletní automatický systém
                         https://github.com/Fatalerorr69

EOF
}

get_user_input() {
    log_step "ZÁKLADNÍ KONFIGURACE"
    
    read -p "🌍 GitHub uživatelské jméno: " GITHUB_USERNAME
    read -p "📧 GitHub email: " GITHUB_EMAIL
    
    # Validace emailu
    if [[ ! "$GITHUB_EMAIL" =~ ^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$ ]]; then
        log_error "Neplatný email formát!"
    fi
}

select_services() {
    log_step "VÝBĚR SLUŽEB K INSTALACI"
    
    declare -A services=(
        ["portainer"]="🛠️  Portainer (Správa kontejnerů)"
        ["heimdall"]="🏠 Heimdall (Hlavní dashboard)"
        ["nextcloud"]="☁️  Nextcloud (Cloudové úložiště)"
        ["vaultwarden"]="🔐 Vaultwarden (Správce hesel)"
        ["jellyfin"]="🎬 Jellyfin (Mediální server)"
        ["homeassistant"]="🏡 Home Assistant (Chytrá domácnost)"
        ["pihole"]="🛡️  Pi-hole (Blokování reklam)"
        ["glances"]="📊 Glances (Monitoring)"
    )
    
    echo "Vyberte služby k instalaci (y/n):"
    echo
    
    for key in "${!services[@]}"; do
        read -p "Nainstalovat ${services[$key]}? (y/N) " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            SELECTED_SERVICES+=("$key")
        fi
    done
    
    log_info "Vybráno služeb: ${#SELECTED_SERVICES[@]}"
}

get_passwords() {
    log_step "NASTAVENÍ HESEL"
    
    read -s -p "🔐 Heslo pro Pi-hole admin: " PIHOLE_PASSWORD
    echo
    read -s -p "🗝️  Admin token pro Vaultwarden: " VAULTWARDEN_PASSWORD
    echo
    
    if [[ ${#PIHOLE_PASSWORD} -lt 8 ]]; then
        log_warning "Heslo pro Pi-hole by mělo mít alespoň 8 znaků"
    fi
}

# =============================================
# INSTALAČNÍ FUNKCE
# =============================================

update_system() {
    log_step "AKTUALIZACE SYSTÉMU"
    sudo apt update && sudo apt upgrade -y
    sudo apt autoremove -y
    log_success "Systém aktualizován"
}

install_basic_tools() {
    log_step "INSTALACE ZÁKLADNÍCH NÁSTROJŮ"
    sudo apt install -y \
        git curl wget vim nano htop \
        tree tmux net-tools \
        python3 python3-pip
    log_success "Základní nástroje nainstalovány"
}

install_docker() {
    log_step "INSTALACE DOCKERU"
    curl -fsSL https://get.docker.com -o get-docker.sh
    sudo sh get-docker.sh
    rm get-docker.sh
    sudo usermod -aG docker "$USER"
    sudo apt install -y docker-compose-plugin
    log_success "Docker nainstalován"
}

setup_directories() {
    log_step "PŘÍPRAVA ADRESÁŘŮ"
    mkdir -p ~/docker-stack/{config,data,backups,scripts}
    mkdir -p ~/docker-stack/config/{portainer,heimdall,nextcloud,vaultwarden,jellyfin,homeassistant,pihole}
    mkdir -p ~/docker-stack/data/{media,documents,backups}
    log_success "Adresářová struktura vytvořena"
}

create_docker_compose() {
    log_step "VYTVÁŘENÍ DOCKER COMPOSE"
    
    local compose_file="$HOME/docker-stack/docker-compose.yml"
    
    cat > "$compose_file" << EOF
version: '3.8'

services:
EOF

    # Přidání služeb podle výběru
    for service in "${SELECTED_SERVICES[@]}"; do
        case $service in
            portainer)
                cat >> "$compose_file" << EOF

  # 🛠️ SPRÁVA KONTEJNERŮ
  portainer:
    image: portainer/portainer-ce:latest
    container_name: portainer
    restart: unless-stopped
    ports: ["9000:9000"]
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock
      - ./config/portainer:/data
    networks: [pi5-network]
EOF
                ;;
            heimdall)
                cat >> "$compose_file" << EOF

  # 🏠 HLAVNÍ DASHBOARD
  heimdall:
    image: lscr.io/linuxserver/heimdall:latest
    container_name: heimdall
    restart: unless-stopped
    ports: ["8080:80"]
    environment:
      TZ: $TIMEZONE
      PUID: 1000
      PGID: 1000
    volumes:
      - ./config/heimdall:/config
    networks: [pi5-network]
EOF
                ;;
            nextcloud)
                cat >> "$compose_file" << EOF

  # ☁️ CLOUDOVÉ ÚLOŽIŠTĚ
  nextcloud:
    image: nextcloud:latest
    container_name: nextcloud
    restart: unless-stopped
    ports: ["8081:80"]
    environment:
      TZ: $TIMEZONE
    volumes:
      - ./config/nextcloud:/var/www/html
      - ./data/documents:/var/www/html/data
    networks: [pi5-network]
EOF
                ;;
            vaultwarden)
                cat >> "$compose_file" << EOF

  # 🔐 SPRÁVCE HESEL
  vaultwarden:
    image: vaultwarden/server:latest
    container_name: vaultwarden
    restart: unless-stopped
    ports: ["8082:80"]
    environment:
      WEBSOCKET_ENABLED: "true"
      SIGNUPS_ALLOWED: "false"
      ADMIN_TOKEN: "$VAULTWARDEN_PASSWORD"
    volumes:
      - ./config/vaultwarden:/data
    networks: [pi5-network]
EOF
                ;;
            jellyfin)
                cat >> "$compose_file" << EOF

  # 🎬 MEDIÁLNÍ SERVER
  jellyfin:
    image: jellyfin/jellyfin:latest
    container_name: jellyfin
    restart: unless-stopped
    ports: ["8096:8096"]
    environment:
      TZ: $TIMEZONE
    volumes:
      - ./config/jellyfin:/config
      - ./data/media:/media
    networks: [pi5-network]
EOF
                ;;
            homeassistant)
                cat >> "$compose_file" << EOF

  # 🏡 CHYTRÁ DOMÁCNOST
  homeassistant:
    image: ghcr.io/home-assistant/home-assistant:stable
    container_name: homeassistant
    restart: unless-stopped
    ports: ["8123:8123"]
    environment:
      TZ: $TIMEZONE
    volumes:
      - ./config/homeassistant:/config
      - /etc/localtime:/etc/localtime:ro
    networks: [pi5-network]
EOF
                ;;
            pihole)
                cat >> "$compose_file" << EOF

  # 🛡️ BLOKOVÁNÍ REKLAM
  pihole:
    image: pihole/pihole:latest
    container_name: pihole
    restart: unless-stopped
    ports:
      - "53:53/tcp"
      - "53:53/udp"
      - "80:80"
    environment:
      TZ: $TIMEZONE
      WEBPASSWORD: "$PIHOLE_PASSWORD"
    volumes:
      - ./config/pihole/etc-pihole:/etc/pihole
      - ./config/pihole/etc-dnsmasq.d:/etc/dnsmasq.d
    networks: [pi5-network]
EOF
                ;;
            glances)
                cat >> "$compose_file" << EOF

  # 📊 MONITORING SYSTÉMU
  glances:
    image: nicolargo/glances:latest
    container_name: glances
    restart: unless-stopped
    ports: ["61208:61208"]
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock:ro
    networks: [pi5-network]
EOF
                ;;
        esac
    done

    cat >> "$compose_file" << EOF

networks:
  pi5-network:
    driver: bridge
EOF

    log_success "Docker Compose soubor vytvořen: $compose_file"
}

deploy_services() {
    log_step "SPOUŠTĚNÍ SLUŽEB"
    
    cd ~/docker-stack
    
    # Vytvoření Docker sítě
    docker network create "$DOCKER_NETWORK" 2>/dev/null || true
    
    # Spuštění služeb
    docker compose up -d
    
    # Čekání na start
    sleep 10
    
    # Kontrola stavu
    log_info "Kontrola stavu kontejnerů..."
    docker compose ps
    
    log_success "Služby úspěšně spuštěny"
}

configure_git() {
    log_step "KONFIGURACE GITU"
    
    git config --global user.name "$GITHUB_USERNAME"
    git config --global user.email "$GITHUB_EMAIL"
    
    log_success "Git nakonfigurován pro: $GITHUB_USERNAME"
}

optimize_system() {
    log_step "OPTIMALIZACE PRO RASPBERRY PI 5"
    
    # Záloha config.txt
    sudo cp /boot/firmware/config.txt /boot/firmware/config.txt.backup 2>/dev/null || true
    
    # Přidání optimalizací
    sudo tee -a /boot/firmware/config.txt > /dev/null << EOF

# Optimalizace pro Raspberry Pi 5
arm_freq=2000
gpu_freq=700
gpu_mem=256
disable_splash=1
EOF

    log_success "Systém optimalizován"
}

configure_security() {
    log_step "KONFIGURACE BEZPEČNOSTI"
    
    # Základní firewall
    sudo ufw --force enable
    sudo ufw allow ssh
    sudo ufw allow 80,443,8080,8081,8082,8096,8123,9000/tcp
    
    log_success "Základní bezpečnostní nastavení dokončeno"
}

create_management_scripts() {
    log_step "VYTVÁŘENÍ SKRIPTŮ PRO SPRÁVU"
    
    local scripts_dir="$HOME/docker-stack/scripts"
    
    # Skript pro aktualizaci
    cat > "$scripts_dir/update-services.sh" << 'EOF'
#!/bin/bash
echo "🔄 Aktualizace všech služeb..."
cd ~/docker-stack
docker compose pull
docker compose up -d
docker system prune -f
echo "✅ Aktualizace dokončena!"
EOF

    # Skript pro zálohu
    cat > "$scripts_dir/backup-data.sh" << 'EOF'
#!/bin/bash
BACKUP_DIR="$HOME/docker-stack/backups"
BACKUP_NAME="backup_$(date +%Y%m%d_%H%M%S)"
echo "📦 Vytváření zálohy: $BACKUP_NAME"
mkdir -p "$BACKUP_DIR/$BACKUP_NAME"
cp -r ~/docker-stack/config "$BACKUP_DIR/$BACKUP_NAME/"
echo "✅ Záloha vytvořena: $BACKUP_DIR/$BACKUP_NAME"
EOF

    chmod +x "$scripts_dir"/*.sh
    log_success "Management skripty vytvořeny"
}

generate_access_info() {
    log_step "GENEROVÁNÍ PŘÍSTUPOVÝCH ÚDAJŮ"
    
    local ip_address
    ip_address=$(hostname -I | awk '{print $1}')
    local access_file="$HOME/docker-stack/ACCESS_INFO.txt"
    
    cat > "$access_file" << EOF
=== RASPBERRY PI 5 ALL-IN-ONE SYSTEM ===
Datum instalace: $(date)
IP adresa: $ip_address

📋 PŘÍSTUPOVÉ ÚDAJE:

EOF

    for service in "${SELECTED_SERVICES[@]}"; do
        case $service in
            portainer)
                echo "🛠️  Portainer (Správa kontejnerů):" >> "$access_file"
                echo "   URL: http://$ip_address:9000" >> "$access_file"
                echo "   Poznámka: První přihlášení vytvoří admin účet" >> "$access_file"
                echo "" >> "$access_file"
                ;;
            heimdall)
                echo "🏠 Heimdall (Dashboard):" >> "$access_file"
                echo "   URL: http://$ip_address:8080" >> "$access_file"
                echo "" >> "$access_file"
                ;;
            nextcloud)
                echo "☁️  Nextcloud (Cloudové úložiště):" >> "$access_file"
                echo "   URL: http://$ip_address:8081" >> "$access_file"
                echo "" >> "$access_file"
                ;;
            vaultwarden)
                echo "🔐 Vaultwarden (Správce hesel):" >> "$access_file"
                echo "   URL: http://$ip_address:8082" >> "$access_file"
                echo "   Admin token: $VAULTWARDEN_PASSWORD" >> "$access_file"
                echo "" >> "$access_file"
                ;;
            jellyfin)
                echo "🎬 Jellyfin (Mediální server):" >> "$access_file"
                echo "   URL: http://$ip_address:8096" >> "$access_file"
                echo "" >> "$access_file"
                ;;
            homeassistant)
                echo "🏡 Home Assistant (Chytrá domácnost):" >> "$access_file"
                echo "   URL: http://$ip_address:8123" >> "$access_file"
                echo "" >> "$access_file"
                ;;
            pihole)
                echo "🛡️  Pi-hole (Blokování reklam):" >> "$access_file"
                echo "   URL: http://$ip_address:80" >> "$access_file"
                echo "   Admin heslo: $PIHOLE_PASSWORD" >> "$access_file"
                echo "" >> "$access_file"
                ;;
            glances)
                echo "📊 Glances (Monitoring):" >> "$access_file"
                echo "   URL: http://$ip_address:61208" >> "$access_file"
                echo "" >> "$access_file"
                ;;
        esac
    done

    cat >> "$access_file" << EOF
🔧 SPRÁVA SYSTÉMU:

Zastavení všech služeb:
  cd ~/docker-stack && docker compose down

Restart služeb:
  cd ~/docker-stack && docker compose restart

Aktualizace služeb:
  ~/docker-stack/scripts/update-services.sh

Záloha dat:
  ~/docker-stack/scripts/backup-data.sh

📞 PODPORA:
Problémy reportujte na GitHub Issues.

EOF

    log_success "Přístupové údaje uloženy do: $access_file"
}

# =============================================
# HLAVNÍ INSTALAČNÍ FUNKCE
# =============================================

main_installation() {
    show_banner
    
    # Kontroly
    check_security
    check_dependencies
    check_raspberry_pi
    
    # Konfigurace
    get_user_input
    select_services
    get_passwords
    
    # Instalace
    update_system
    install_basic_tools
    configure_git
    install_docker
    setup_directories
    create_docker_compose
    deploy_services
    
    # Další nastavení
    optimize_system
    configure_security
    create_management_scripts
    generate_access_info
    
    # Dokončení
    log_step "INSTALACE DOKONČENA 🎉"
    
    local ip_address
    ip_address=$(hostname -I | awk '{print $1}')
    
    echo "🎉 Všechny služby byly úspěšně nainstalovány!"
    echo ""
    echo "📊 PŘEHLED SLUŽEB:"
    for service in "${SELECTED_SERVICES[@]}"; do
        echo "   ✅ $service"
    done
    echo ""
    echo "🌐 PŘÍSTUPOVÉ ÚDAJE:"
    echo "   Soubor: ~/docker-stack/ACCESS_INFO.txt"
    echo "   IP adresa: $ip_address"
    echo ""
    echo "🔧 DALŠÍ KROKY:"
    echo "   1. Pro aplikování Docker skupiny se odhlaste a přihlaste"
    echo "   2. Přístupové údaje najdete v ACCESS_INFO.txt"
    echo "   3. Management skripty jsou v ~/docker-stack/scripts/"
    echo ""
    
    read -p "Chcete systém restartovat? (doporučeno) (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        log_info "Restartování systému..."
        sudo reboot
    fi
}

# =============================================
# SPUŠTĚNÍ SKRIPTU
# =============================================

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    case "${1:-}" in
        "--help"|"-h")
            echo "Použití: $0 [option]"
            echo "Options:"
            echo "  --help     Zobrazení nápovědy"
            echo "  --info     Informace o skriptu"
            echo "  --quick    Rychlá instalace (všechny služby)"
            echo ""
            echo "Příklad: $0 --quick"
            ;;
        "--info")
            echo "Ultimate Raspberry Pi 5 Installer v3.0"
            echo "Kompletní automatický instalační systém"
            ;;
        "--quick")
            # Rychlá instalace s výchozími hodnotami
            SELECTED_SERVICES=("portainer" "heimdall" "nextcloud" "vaultwarden" "jellyfin" "homeassistant" "pihole" "glances")
            PIHOLE_PASSWORD="ChangeThisPassword123"
            VAULTWARDEN_PASSWORD="ChangeThisToken123"
            main_installation
            ;;
        *)
            main_installation
            ;;
    esac
fi
