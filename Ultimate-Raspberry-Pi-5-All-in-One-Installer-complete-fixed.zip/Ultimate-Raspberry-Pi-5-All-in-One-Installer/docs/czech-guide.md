# 🇨🇿 Kompletní Český Návod

## Úvod

Tento návod vás provede kompletní instalací Ultimate Raspberry Pi 5 All-in-One systému.

## Příprava Raspberry Pi 5

1. **Stáhněte Raspberry Pi Imager** z [oficiální stránky](https://www.raspberrypi.com/software/)
2. **Vyberte Raspberry Pi OS 64-bit** (Bookworm nebo novější)
3. **Nakonfigurujte předinstalaci**:
   - Povolte SSH
   - Nastavte Wi-Fi (pokud používáte)
   - Nastavte locale na češtinu

## Instalace

### Rychlá instalace (doporučeno)

```bash
curl -sSL https://raw.githubusercontent.com/Fatalerorr69/Ultimate-Raspberry-Pi-5-All-in-One-Installer/main/install.sh | bash


### Ruční instalace
git clone https://github.com/Fatalerorr69/Ultimate-Raspberry-Pi-5-All-in-One-Installer.git
cd Ultimate-Raspberry-Pi-5-All-in-One-Installer
chmod +x install.sh
./install.sh

Konfigurace služeb
Pi-hole
Po instalaci přejděte na http://vaše-ip:80

Přihlaste se s heslem které jste nastavili

V routeru nastavte DNS na IP vašeho Raspberry Pi

Nextcloud
Přejděte na http://vaše-ip:8081

Vytvořte administrátorský účet

Nastavte databázi na SQLite

Řešení problémů
Služby se nespustí
bash
# Zkontrolujte logy kontejneru
docker logs název-kontejneru

# Restartujte služby
cd ~/docker-stack
docker compose restart
Zapomenuté heslo
Hesla jsou uložena v ~/docker-stack/ACCESS_INFO.txt
