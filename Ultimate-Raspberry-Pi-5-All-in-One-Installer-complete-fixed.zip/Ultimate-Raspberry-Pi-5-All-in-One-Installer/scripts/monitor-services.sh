#!/bin/bash
# Skript pro monitorování stavu služeb
set -euo pipefail

echo "📊 Monitorování služeb Ultimate Raspberry Pi 5"
echo "=============================================="

cd ~/docker-stack

# Základní informace
echo "🤖 Hostname: $(hostname)"
echo "🌐 IP adresa: $(hostname -I)"
echo "📅 Datum: $(date)"
echo ""

# Stav Dockeru
echo "🐳 Docker status:"
sudo systemctl is-active docker
echo ""

# Stav kontejnerů
echo "📦 Stav kontejnerů:"
docker compose ps
echo ""

# Využití zdrojů
echo "💾 Využití disku:"
df -h | grep -v tmpfs
echo ""

# Využití paměti
echo "🧠 Využití paměti:"
free -h
echo ""

# Teplota
echo "🌡️  Teplota CPU:"
vcgencmd measure_temp
echo ""

# Logy z poslední hodiny
echo "📋 Logy z poslední hodiny:"
docker compose logs --since=1h | tail -20
