# Bezpečnostní checklist
- Nesesílat hesla v repozitáři.
- Použít TLS pro web UI (nginx + certbot).
- ADB: nikdy nepřístupňovat veřejně bez tunelu.
- Docker: minimalizovat capabilities, nepoužívat privileged pokud není nutné.
- CI: shellcheck, pylint, trivy.
