## TLS / Reverse proxy setup (nginx + certbot)

This repo includes a sample nginx config under `nginx/conf.d/urpi.conf` and a docker-compose addition for `nginx` + `certbot`.

Basic steps to obtain certificates using certbot (manual one-time):
1. Ensure DNS for your domain points to the host public IP.
2. Start the stack exposing port 80 temporarily to allow HTTP challenge:
   `docker compose up -d --build nginx dashboard`
3. Run certbot to obtain certs (example - adjust domain):
   `docker run --rm -v $(pwd)/nginx/ssl:/etc/letsencrypt -v $(pwd)/nginx/conf.d:/etc/nginx/conf.d \
     certbot/certbot certonly --webroot -w /var/www/dashboard -d yourdomain.com -d www.yourdomain.com`
4. After certs are in `nginx/ssl`, restart docker compose: `docker compose up -d`

IMPORTANT: Replace `yourdomain` in `nginx/conf.d/urpi.conf` with your actual domain names.
