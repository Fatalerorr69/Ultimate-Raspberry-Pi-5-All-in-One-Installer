# 📖 Podrobný Instalační Návod - Ultimate Raspberry Pi 5 Installer

## 🎯 Úvod

Tento návod vás provede kompletní instalací všech-in-one systému na Raspberry Pi 5.

## 🔰 Rychlá instalace (pro začátečníky)

### Jedním příkazem
```bash
curl -sSL https://raw.githubusercontent.com/Fatalerorr69/Ultimate-Raspberry-Pi-5-All-in-One-Installer/main/install.sh | bash
