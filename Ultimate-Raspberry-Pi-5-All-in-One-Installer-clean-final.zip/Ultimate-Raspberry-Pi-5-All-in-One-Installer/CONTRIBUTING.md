# 🤝 Průvodce přispíváním

Vítáme příspěvky od komunity! Zde je jak můžete pomoci:

## 🐛 Nahlášení chyby

1. Zkontrolujte zda chyba již není nahlášena v [Issues](https://github.com/Fatalerorr69/Ultimate-Raspberry-Pi-5-All-in-One-Installer/issues)
2. Vytvořte nové Issue s popisem problému
3. Přidejte logy a kroky k reprodukci

## 💡 Návrhy vylepšení

1. Otevřete Discussion nebo Issue
2. Popište své nápady
3. Diskutujte s komunitou

## 🔧 Vývojářské příspěvky

1. Forkněte repozitář
2. Vytvořte feature branch (`git checkout -b feature/amazing-feature`)
3. Commitněte změny (`git commit -m 'Add amazing feature'`)
4. Pushněte do branch (`git push origin feature/amazing-feature`)
5. Otevřete Pull Request

## 📝 Standardy kódu

- Používejte popisné názvy proměnných
- Přidávejte komentáře k složitějším částem kódu
- Testujte změny na čistém Raspberry Pi OS

## 📚 Dokumentace

Vylepšení dokumentace jsou také vítána!
