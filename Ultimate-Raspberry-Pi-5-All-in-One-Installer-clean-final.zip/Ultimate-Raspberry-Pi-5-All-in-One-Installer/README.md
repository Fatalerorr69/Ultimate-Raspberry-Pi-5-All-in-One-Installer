# 🍃 Ultimate Raspberry Pi 5 All-in-One Installer

**Kompletní automatický instalační systém pro Raspberry Pi 5 s jednotným webovým rozhraním**

## 📋 Obsah
- [🌟 Funkce](#-funkce)
- [🛠️ Požadavky](#-požadavky)
- [🚀 Rychlý start](#-rychlé-spuštění)
- [📦 Instalované služby](#-instalované-služby)
- [🔧 Podrobná instalace](#-podrobný-instalační-manuál)
- [🌐 Přístup ke službám](#-přístup-ke-službám)
- [⚙️ Konfigurace](#-konfigurace)
- [🔄 Správa systému](#-správa-systému)
- [❌ Řešení problémů](#-řešení-problémů)
- [📞 Podpora](#-podpora)

## 🌟 Funkce

- **🎯 Jednoduchá instalace** - Jedním příkazem spustíte kompletní systém
- **🌐 Jednotné webové rozhraní** - Všechny služby přístupné přes hlavní dashboard
- **🐳 Docker-based architektura** - Izolované a snadno spravovatelné služby
- **📊 Komplexní monitoring** - Přehled o výkonu a stavu systému
- **🔒 Automatické aktualizace** - Watchtower se stará o aktuálnost kontejnerů
- **📱 Responzivní design** - Přístup z jakéhokoli zařízení

## 🛠️ Požadavky

### Hardware
- **Raspberry Pi 5** (doporučeno 8GB RAM)
- **Aktivní chlazení** - povinné pro stabilní provoz
- **SSD disk přes USB 3.0** nebo kvalitní microSD karta (min. 32GB)
- **Napájecí zdroj 5V/5A**
- **Ethernet připojení** nebo stabilní Wi-Fi

### Software
- **Raspberry Pi OS (64-bit)** - Bookworm nebo novější
- **Připojení k internetu** - pro stažení Docker imagí

## 🚀 Rychlé spuštění

```bash
# Stažení a spuštění instalačního skriptu
curl -sSL https://raw.githubusercontent.com/Fatalerorr69/Ultimate-Raspberry-Pi-5-All-in-One-Installer/main/install.sh | bash
