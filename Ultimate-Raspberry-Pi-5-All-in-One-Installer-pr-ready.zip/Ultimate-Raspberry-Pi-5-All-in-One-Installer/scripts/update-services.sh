#!/bin/bash
# Skript pro aktualizaci všech služeb
set -euo pipefail

echo "🔄 Ultimate Raspberry Pi 5 - Aktualizace služeb"
echo "================================================"

cd ~/docker-stack

# Kontrola existence docker-compose.yml
if [ ! -f "docker-compose.yml" ]; then
    echo "❌ Soubor docker-compose.yml neexistuje!"
    exit 1
fi

echo "📥 Stahování nejnovějších verzí..."
docker compose pull

echo "🔄 Restartování služeb..."
docker compose up -d

echo "🧹 Čištění starých imagí..."
docker system prune -f

echo "✅ Aktualizace dokončena!"
echo ""
echo "📊 Stav služeb:"
docker compose ps
