```markdown
# ⚙️ Pokročilá Konfigurace

## Vlastní Docker Compose

Můžete upravit `docker-compose.yml` pro přidání vlastních služeb:

```yaml
  # Vlastní služba
  moje-sluzba:
    image: vlastni/image:latest
    container_name: moje-sluzba
    restart: unless-stopped
    ports: ["3000:3000"]
    networks: [pi5-network]
Optimalizace výkonu
Zvýšení GPU paměti
V /boot/firmware/config.txt přidejte:

text
gpu_mem=512
Swap file
Zvětšete swap file pro lepší výkon:

bash
sudo nano /etc/dphys-swapfile
# Změňte CONF_SWAPSIZE=1024
sudo systemctl restart dphys-swapfile
Bezpečnostní vylepšení
Fail2Ban
Instalace Fail2Ban pro ochranu před útoky:

bash
sudo apt install fail2ban
SSL certifikáty
Nastavení SSL pomocí Let's Encrypt:

bash
sudo apt install certbot python3-certbot-nginx
Monitorování
Prometheus + Grafana
Přidejte monitoring stack:

yaml
  prometheus:
    image: prom/prometheus:latest
    # ... konfigurace

  grafana:
    image: grafana/grafana:latest
    # ... konfigurace
Zálohování na cloud
Automatické zálohování na AWS S3
Přidejte do crontabu:

bash
0 2 * * * /home/pi/docker-stack/scripts/backup-data.sh && aws s3 sync ~/docker-stack/backups s3://muj-bucket/backups
text

