
## Vylepšená architektura (Docker + Dashboard)

Tento repozitář byl rozšířen o:
- `docker-compose.yml` pro spuštění služby `dashboard`, `adb` a `portainer`.
- `dashboard/` obsahuje jednoduchý Flask prototyp s uploadem APK a voláním ADB.
- `waydroid-install.sh` a bezpečnostní checklist v `security.md`.

Spuštění:
```
./install.sh
```
Pozor: ADB kontejner používá privileged a host USB passthrough. Používej v zabezpečeném prostředí.
