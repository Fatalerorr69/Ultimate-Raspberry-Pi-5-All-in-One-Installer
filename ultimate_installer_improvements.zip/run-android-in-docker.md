
# Běh Androidu na Raspberry Pi 5 - přístupy (shrnutí)

Možnosti (seřazeno podle doporučení):
1) Waydroid (container-based) - pokud kernel podporuje binder/ashmem. Nejlepší výkon a integrace.
2) LXC / system containers - běh Android userspace v system containeru (lepší izolace než plnohodnotný kontejner).
3) KVM / libvirt VM - pokud kernel a hardware podporují virtualizaci (nejbližší k "skutečnému" Androidu).
4) QEMU v Dockeru (qemu-user/qemu-system) - emulace jiné architektury; značně nižší výkon, ale univerzální.
5) Docker-Android (VNC) - existují přístupy, které používají VNC a ADB v kontejneru. Výkon omezený.

Důraz:
- Pro skutečnou práci s Android zařízeními preferujte ADB + fyzické zařízení (rychlé a spolehlivé).
- Pro spouštění Android aplikací na RPi5 preferujte Waydroid pokud kernel podporuje binder/ashmem.
- Pro testování ROM / low-level operací použijte VM/KVM nebo fyzické zařízení; QEMU emulace je vhodná pro CI a automatizaci, nikoliv pro intenzivní používání.

Bezpečnostní poznámky:
- Nikdy nezveřejňujte ADB server na veřejný síťový port bez silné autentizace.
- ADB v Dockeru používejte na izolované síti a ideálně přes SSH tunel.
