
# Bezpečnostní checklist pro projekt

1) Neskladovat hesla v repozitáři (žádné hardcoded hesla).
2) Používat TLS pro webové rozhraní (Let's Encrypt / ACME).
3) ADB: nikdy nepřístupnit veřejně; použít SSH přeposílání / VPN.
4) Docker kontejnery:
   - minimalizovat CAPABILITIES
   - nepoužívat privileged pokud není nutné
   - používat read-only volumes kde to jde
5) Oddělení dat a konfigurací přes volumes a secrets (Docker secrets / Vault)
6) Logging: sbírat logy do centrálního stacku a rotovat
7) CI: spouštět linting (shellcheck), scan image (trivy), testy bezpečnosti
8) Pravidelné aktualizace systémových balíčků
