#!/bin/bash
# waydroid-install.sh - kontroly a instalace Waydroid na Raspberry Pi 5
# Tento skript provádí ověření a ukáže kroky. Spouštějte jako root.
set -euo pipefail

echo "1) Kontrola kernel modulů binder a ashmem..."
if ! grep -qE "binder|ashmem" /proc/modules 2>/dev/null; then
  echo "  Kernel modul binder/ashmem není načtený. Pokusím se načíst (pokud jsou k dispozici)."
  modprobe ashmem_linux || true
  modprobe binder_linux || true
fi

if [ ! -c /dev/binder ] && [ ! -c /dev/binderfs ]; then
  echo "  Varování: /dev/binder neexistuje. Waydroid vyžaduje podporu binder/ashmem v kernelu."
  echo "  Pokud kernel nemá podporu, zvažte custom kernel nebo použití LXC/KVM řešení."
fi

echo "2) Doporučení: aktualizovat systém a nainstalovat prerequisites (python3, curl, lxc if needed)."
echo "   apt update && apt install -y curl lvm2 wget ca-certificates"

echo "3) Instalace Waydroid (stručně):"
echo "   curl -s https://repo.waydro.id/waydroid.gpg | gpg --dearmour -o /usr/share/keyrings/waydroid-archive-keyring.gpg"
echo "   echo 'deb [signed-by=/usr/share/keyrings/waydroid-archive-keyring.gpg] https://repo.waydro.id/ bullseye main' | tee /etc/apt/sources.list.d/waydroid.list"
echo "   apt update && apt install -y waydroid"
echo "   waydroid init"
echo "   systemctl enable --now waydroid-container"

echo "4) Poznámky:"
echo " - Waydroid funguje nejlépe na 64-bit systému s binder/ashmem supportem."
echo " - Pokud Waydroid není možný, použijte LXC container s Android image nebo KVM/VM."