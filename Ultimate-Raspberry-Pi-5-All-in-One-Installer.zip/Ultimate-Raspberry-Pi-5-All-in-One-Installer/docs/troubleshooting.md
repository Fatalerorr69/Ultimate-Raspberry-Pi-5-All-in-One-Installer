text

### 📄 docs/troubleshooting.md
Obsah:

```markdown
# ❌ Řešení Problémů

## Běžné problémy a jejich řešení

### Docker se nespustí
```bash
# Restartujte Docker službu
sudo systemctl restart docker

# Zkontrolujte stav
sudo systemctl status docker
Kontejnery se nespustí
bash
# Zkontrolujte logy konkrétního kontejneru
docker logs portainer

# Zkontrolujte jestli není port již používán
sudo netstat -tulpn | grep :9000
Nedostatek místa na disku
bash
# Zkontrolujte volné místo
df -h

# Vyčistěte Docker cache
docker system prune -a
Problémy se sítí
bash
# Zkontrolujte Docker sítě
docker network ls

# Zkontrolujte jestli je kontejner v síti
docker inspect portainer | grep Network
Obnovení ze zálohy
bash
# Zastavte služby
cd ~/docker-stack
docker compose down

# Obnovte data ze zálohy
cp -r ~/docker-stack/backups/backup_20240101_120000/config/* ~/docker-stack/config/

# Spusťte služby
docker compose up -d
Kontaktování podpory
Před kontaktováním podpory připravte:

Výstup z docker compose ps

Logy z problémového kontejneru: docker logs název-kontejneru

Výstup z docker network ls

Verzi OS: cat /etc/os-release

text

