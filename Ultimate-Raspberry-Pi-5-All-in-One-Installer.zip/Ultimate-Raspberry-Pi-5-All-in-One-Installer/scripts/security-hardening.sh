#!/bin/bash
# Skript pro bezpečnostní hardening

echo "🔒 Bezpečnostní hardening Raspberry Pi 5"
echo "========================================"

# Základní firewall
sudo ufw --force reset
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow 80,443,8080,8081,8082,8096,8123,9000/tcp
sudo ufw --force enable

# SSH hardening
sudo sed -i 's/#PermitRootLogin prohibit-password/PermitRootLogin no/' /etc/ssh/sshd_config
sudo sed -i 's/#PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config
sudo systemctl restart ssh

# Fail2Ban
sudo apt update
sudo apt install -y fail2ban

sudo tee /etc/fail2ban/jail.local > /dev/null << EOF
[sshd]
enabled = true
port = ssh
filter = sshd
logpath = /var/log/auth.log
maxretry = 3
bantime = 3600
EOF

sudo systemctl enable fail2ban
sudo systemctl start fail2ban

echo "✅ Bezpečnostní hardening dokončen"
