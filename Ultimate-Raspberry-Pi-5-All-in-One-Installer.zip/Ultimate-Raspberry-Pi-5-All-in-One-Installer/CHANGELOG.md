# Changelog

Všechny významné změny v tomto projektu budou zdokumentovány v tomto souboru.

Formát je založen na [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
a tento projekt se drží [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [3.0.0] - 2024-01-01

### Added
- Kompletní přepracování instalačního skriptu
- Interaktivní výběr služeb
- Automatická konfigurace hesel
- Optimalizace pro Raspberry Pi 5
- Bezpečnostní hardening
- Skripty pro správu (aktualizace, záloha)

### Changed
- Architektura založená na Docker Compose
- Vylepšená dokumentace
- Lepší logování a error handling

### Fixed
- Opraveny bezpečnostní problémy
- Vylepšena kompatibilita s Raspberry Pi OS Bookworm

## [2.0.0] - 2023-12-01

### Added
- Základní podpora Dockeru
- Konfigurace základních služeb

### Changed
- Přechod na Docker-based instalaci

## [1.0.0] - 2023-11-01

### Added
- První verze instalačního skriptu
- Základní služby: Pi-hole, Nextcloud, Home Assistant
