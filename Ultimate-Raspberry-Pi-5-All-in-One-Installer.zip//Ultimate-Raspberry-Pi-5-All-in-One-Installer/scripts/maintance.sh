#!/bin/bash

# =============================================
# RASPBERRY PI 5 DOCKER MAINTENANCE SCRIPT
# Optimalizováno pro Raspberry Pi 5 + Docker stack
# =============================================

# Konfigurace
DOCKER_COMPOSE_DIR="$HOME/docker-stack"
BACKUP_DIR="$HOME/docker-backups"
LOG_FILE="$HOME/maintenance.log"

# Barvy pro výstup
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Funkce pro logování
log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1" | tee -a "$LOG_FILE"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1" | tee -a "$LOG_FILE"
}

# Kontrola oprávnění
check_root() {
    if [[ $EUID -eq 0 ]]; then
        log_error "Skript by neměl být spouštěn jako root!"
        exit 1
    fi
}

# Kontrola Docker instalace
check_docker() {
    if ! command -v docker &> /dev/null; then
        log_error "Docker není nainstalován!"
        exit 1
    fi
}

# =============================================
# ZÁKLADNÍ ÚDRŽBA SYSTÉMU
# =============================================

system_update() {
    log "Aktualizace systému Raspberry Pi OS"
    sudo apt update && sudo apt upgrade -y
    sudo apt autoremove -y
    log "Aktualizace systému dokončena"
}

docker_system_cleanup() {
    log "Čištění Docker systému"
    docker system prune -f
    docker volume prune -f
    log "Docker cleanup dokončen"
}

# =============================================
# DOCKER CONTAINER MANAGEMENT
# =============================================

container_status() {
    log "Stav Docker kontejnerů"
    cd "$DOCKER_COMPOSE_DIR"
    docker-compose ps
}

restart_services() {
    log "Restartování všech služeb"
    cd "$DOCKER_COMPOSE_DIR"
    docker-compose down
    sleep 5
    docker-compose up -d
    log "Restart služeb dokončen"
}

update_containers() {
    log "Aktualizace Docker kontejnerů"
    cd "$DOCKER_COMPOSE_DIR"
    docker-compose pull
    docker-compose up -d
    log "Aktualizace kontejnerů dokončena"
}

# =============================================
# MONITORING A DIAGNOSTIKA
# =============================================

system_health_check() {
    log "Kompletní kontrola zdraví systému"
    
    echo -e "\n${CYAN}=== SYSTEM INFORMATION ===${NC}"
    echo "Hostname: $(hostname)"
    echo "Uptime: $(uptime -p)"
    echo "CPU Temperature: $(vcgencmd measure_temp)"
    
    echo -e "\n${CYAN}=== DISK USAGE ===${NC}"
    df -h / /home
    
    echo -e "\n${CYAN}=== MEMORY USAGE ===${NC}"
    free -h
    
    echo -e "\n${CYAN}=== DOCKER STATUS ===${NC}"
    docker stats --no-stream --format "table {{.Container}}\t{{.CPUPerc}}\t{{.MemUsage}}\t{{.NetIO}}"
    
    echo -e "\n${CYAN}=== RUNNING CONTAINERS ===${NC}"
    docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
}

performance_monitor() {
    log "Monitorování výkonu v reálném čase"
    echo "Stiskněte Ctrl+C pro ukončení monitorování"
    docker stats
}

# =============================================
# ZÁLOHA A OBNOVA
# =============================================

backup_docker_stack() {
    local backup_name="docker-backup-$(date +%Y%m%d-%H%M%S)"
    local backup_path="$BACKUP_DIR/$backup_name"
    
    log "Zálohování Docker stacku do: $backup_path"
    
    mkdir -p "$backup_path"
    
    # Záloha konfigurace
    cp -r "$DOCKER_COMPOSE_DIR/config" "$backup_path/"
    
    # Záloha docker-compose.yml
    cp "$DOCKER_COMPOSE_DIR/docker-compose.yml" "$backup_path/"
    
    # Export databází (pokud existují)
    if docker ps | grep -q mysql; then
        docker exec mysql mysqldump -u root --all-databases > "$backup_path/mysql-backup.sql"
    fi
    
    # Komprese zálohy
    tar -czf "$backup_path.tar.gz" -C "$BACKUP_DIR" "$backup_name"
    rm -rf "$backup_path"
    
    log "Záloha dokončena: $backup_path.tar.gz"
}

restore_docker_stack() {
    local backup_file="$1"
    
    if [[ -z "$backup_file" ]]; then
        log_error "Nebyl zadán záložní soubor"
        return 1
    fi
    
    log "Obnova Docker stacku ze souboru: $backup_file"
    
    # Zastavení služeb
    cd "$DOCKER_COMPOSE_DIR"
    docker-compose down
    
    # Extrakce zálohy
    tar -xzf "$backup_file" -C "$BACKUP_DIR"
    local backup_dir=$(tar -tzf "$backup_file" | head -1 | cut -f1 -d"/")
    
    # Obnova konfigurace
    cp -r "$BACKUP_DIR/$backup_dir/config/"* "$DOCKER_COMPOSE_DIR/config/"
    cp "$BACKUP_DIR/$backup_dir/docker-compose.yml" "$DOCKER_COMPOSE_DIR/"
    
    # Spuštění služeb
    docker-compose up -d
    
    log "Obnova dokončena"
}

# =============================================
# SÍŤOVÁ DIAGNOSTIKA
# =============================================

network_diagnostics() {
    log "Síťová diagnostika"
    
    echo -e "\n${CYAN}=== NETWORK INTERFACES ===${NC}"
    ip addr show
    
    echo -e "\n${CYAN}=== OPEN PORTS ===${NC}"
    netstat -tulpn | grep LISTEN
    
    echo -e "\n${CYAN}=== DOCKER NETWORKS ===${NC}"
    docker network ls
    
    echo -e "\n${CYAN}=== CONNECTIVITY TEST ===${NC}"
    ping -c 3 google.com
}

port_scanner() {
    local target=${1:-localhost}
    log "Skenování portů na: $target"
    nmap -sS -T4 "$target"
}

# =============================================
# BEZPEČNOSTNÍ AUDIT
# =============================================

security_audit() {
    log "Bezpečnostní audit Docker prostředí"
    
    echo -e "\n${CYAN}=== DOCKER SECURITY CHECKS ===${NC}"
    
    # Kontrola kontejnerů běžících jako root
    echo "Kontejnery běžící jako root:"
    docker ps --format "table {{.Names}}\t{{.ID}}" | while read line; do
        container=$(echo $line | awk '{print $1}')
        if [[ "$container" != "NAMES" ]]; then
            user=$(docker exec "$container" whoami 2>/dev/null || echo "unknown")
            if [[ "$user" == "root" ]]; then
                echo "WARNING: $container běží jako root"
            fi
        fi
    done
    
    # Kontrola exposed portů
    echo -e "\nExposed porty:"
    docker ps --format "table {{.Names}}\t{{.Ports}}"
    
    # Kontrola síťových nastavení
    echo -e "\nSíťová nastavení:"
    docker network ls
}

# =============================================
# OPTIMALIZACE PRO RASPBERRY PI 5
# =============================================

optimize_pi5() {
    log "Optimalizace pro Raspberry Pi 5"
    
    # Optimalizace swapu
    sudo sed -i 's/CONF_SWAPSIZE=100/CONF_SWAPSIZE=512/' /etc/dphys-swapfile
    sudo systemctl restart dphys-swapfile
    
    # Optimalizace I/O scheduler
    echo 'echo mq-deadline > /sys/block/sda/queue/scheduler' | sudo tee -a /etc/rc.local
    
    # Zvýšení limitů pro Docker
    echo -e "{\n  \"data-root\": \"/opt/docker\"\n}" | sudo tee /etc/docker/daemon.json
    sudo systemctl restart docker
    
    log "Optimalizace dokončena"
}

# =============================================
# HLAVNÍ MENU
# =============================================

show_menu() {
    echo -e "${CYAN}"
    echo "=========================================="
    echo "  RASPBERRY PI 5 DOCKER MAINTENANCE MENU"
    echo "=========================================="
    echo -e "${NC}"
    
    echo "1)  Aktualizovat systém"
    echo "2)  Stav kontejnerů"
    echo "3)  Restartovat služby"
    echo "4)  Aktualizovat kontejnery"
    echo "5)  Kontrola zdraví systému"
    echo "6)  Monitorování výkonu"
    echo "7)  Záloha Docker stacku"
    echo "8)  Síťová diagnostika"
    echo "9)  Bezpečnostní audit"
    echo "10) Optimalizace Pi 5"
    echo "11) Čištění Dockeru"
    echo "12) Skenování portů"
    echo "13) Konec"
    echo -e "${CYAN}==========================================${NC}"
}

main() {
    check_root
    check_docker
    
    while true; do
        show_menu
        read -p "Vyberte možnost (1-13): " choice
        
        case $choice in
            1) system_update ;;
            2) container_status ;;
            3) restart_services ;;
            4) update_containers ;;
            5) system_health_check ;;
            6) performance_monitor ;;
            7) backup_docker_stack ;;
            8) network_diagnostics ;;
            9) security_audit ;;
            10) optimize_pi5 ;;
            11) docker_system_cleanup ;;
            12) read -p "Zadejte cílovou IP/hostname: " target; port_scanner "$target" ;;
            13) log "Ukončování skriptu"; exit 0 ;;
            *) log_warning "Neplatná volba" ;;
        esac
        
        echo
        read -p "Stiskněte Enter pro pokračování..."
        clear
    done
}

# Spuštění hlavní funkce
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi
