```bash
#!/bin/bash
# Skript pro optimalizaci Raspberry Pi 5

echo "🚀 Optimalizace Raspberry Pi 5"
echo "=============================="

# Záloha původního config.txt
sudo cp /boot/firmware/config.txt /boot/firmware/config.txt.backup

# Přidání optimalizací
sudo tee -a /boot/firmware/config.txt > /dev/null << EOF

# Ultimate Raspberry Pi 5 Optimizations
over_voltage=2
arm_freq=2000
gpu_freq=700
force_turbo=0
disable_splash=1
boot_delay=0
gpu_mem=256
dtoverlay=vc4-kms-v3d
temp_soft_limit=70
EOF

# Optimalizace swapu
sudo sed -i 's/CONF_SWAPSIZE=100/CONF_SWAPSIZE=512/' /etc/dphys-swapfile
sudo systemctl restart dphys-swapfile

# Optimalizace sysctl
sudo tee -a /etc/sysctl.conf > /dev/null << EOF
# Network optimizations
net.core.rmem_max = 16777216
net.core.wmem_max = 16777216
net.ipv4.tcp_rmem = 4096 87380 16777216
net.ipv4.tcp_wmem = 4096 16384 16777216
EOF

echo "✅ Optimalizace dokončena. Restartujte systém."
