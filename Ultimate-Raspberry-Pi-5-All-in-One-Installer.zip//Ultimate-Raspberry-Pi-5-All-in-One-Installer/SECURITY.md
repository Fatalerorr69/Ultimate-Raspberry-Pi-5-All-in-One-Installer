# 🔒 Bezpečnostní politika

## Reportování zranitelností

Pokud najdete bezpečnostní chybu, **NEreportujte ji přes veřejné Issues**. Místo toho:

1. Pošlete email na: 
2. Popište zranitelnost co nejpodrobněji
3. Počkejte na naši odpověď

## Bezpečnostní doporučení

### Pro uživatele
- Pravidelně měňte hesla služeb
- Používejte silná hesla
- Aktualizujte systém a služby
- Zálohujte důležitá data

### Pro vývojáře
- Nikdy neukládejte citlivé údaje do kódu
- Vždy validujte uživatelský vstup
- Používejte oficiální Docker images
